"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsLambdaStack = void 0;
const lambda = require("aws-cdk-lib/aws-lambda");
const cdk = require("aws-cdk-lib");
const path = require("path");
const apigateway = require("aws-cdk-lib/aws-apigateway");
class ProductsLambdaStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const lambdaFunction = new lambda.Function(this, 'getProductsList', {
            runtime: lambda.Runtime.NODEJS_20_X,
            memorySize: 1024,
            timeout: cdk.Duration.seconds(5),
            handler: 'handler.main',
            code: lambda.Code.fromAsset(path.join(__dirname, './')),
        });
        const api = new apigateway.RestApi(this, "products-api", {
            restApiName: "Products API Gateway",
            description: "This API serves the Lambda functions."
        });
        const ProductsLambdaIntegration = new apigateway.LambdaIntegration(lambdaFunction, {
            integrationResponses: [
                {
                    statusCode: '200',
                }
            ],
            proxy: false,
        });
        const productsResource = api.root.addResource("products");
        productsResource.addMethod('GET', ProductsLambdaIntegration, {
            methodResponses: [{ statusCode: '200' }]
        });
        productsResource.addCorsPreflight({
            allowOrigins: ['https://d215txe1wllrtv.cloudfront.net/'],
            allowMethods: ['GET'],
        });
    }
}
exports.ProductsLambdaStack = ProductsLambdaStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdHMtbGFtYmRhLXN0YWNrLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvZHVjdHMtbGFtYmRhLXN0YWNrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUFpRDtBQUNqRCxtQ0FBbUM7QUFDbkMsNkJBQTZCO0FBRTdCLHlEQUF5RDtBQUV6RCxNQUFhLG1CQUFvQixTQUFRLEdBQUcsQ0FBQyxLQUFLO0lBQzlDLFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBc0I7UUFDNUQsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEIsTUFBTSxjQUFjLEdBQUcsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUNoRSxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ25DLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLE9BQU8sRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDaEMsT0FBTyxFQUFFLGNBQWM7WUFDdkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzFELENBQUMsQ0FBQztRQUVILE1BQU0sR0FBRyxHQUFHLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3JELFdBQVcsRUFBRSxzQkFBc0I7WUFDbkMsV0FBVyxFQUFFLHVDQUF1QztTQUN2RCxDQUFDLENBQUM7UUFFSCxNQUFNLHlCQUF5QixHQUFHLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsRUFBRTtZQUMvRSxvQkFBb0IsRUFBRTtnQkFDbEI7b0JBQ0ksVUFBVSxFQUFFLEtBQUs7aUJBQ3BCO2FBQ0o7WUFDRCxLQUFLLEVBQUUsS0FBSztTQUNmLENBQUMsQ0FBQztRQUNILE1BQU0sZ0JBQWdCLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUQsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSx5QkFBeUIsRUFBRTtZQUN6RCxlQUFlLEVBQUUsQ0FBRSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsQ0FBRTtTQUM3QyxDQUFDLENBQUM7UUFDSCxnQkFBZ0IsQ0FBQyxnQkFBZ0IsQ0FBQztZQUM5QixZQUFZLEVBQUUsQ0FBQyx3Q0FBd0MsQ0FBQztZQUN4RCxZQUFZLEVBQUUsQ0FBQyxLQUFLLENBQUM7U0FDeEIsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztDQUNKO0FBbENELGtEQWtDQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBhcGlnYXRld2F5IGZyb20gXCJhd3MtY2RrLWxpYi9hd3MtYXBpZ2F0ZXdheVwiO1xuXG5leHBvcnQgY2xhc3MgUHJvZHVjdHNMYW1iZGFTdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG4gICAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM/OiBjZGsuU3RhY2tQcm9wcykge1xuICAgICAgICBzdXBlcihzY29wZSwgaWQsIHByb3BzKTtcblxuICAgICAgICBjb25zdCBsYW1iZGFGdW5jdGlvbiA9IG5ldyBsYW1iZGEuRnVuY3Rpb24odGhpcywgJ2dldFByb2R1Y3RzTGlzdCcsIHtcbiAgICAgICAgICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLk5PREVKU18yMF9YLFxuICAgICAgICAgICAgbWVtb3J5U2l6ZTogMTAyNCxcbiAgICAgICAgICAgIHRpbWVvdXQ6IGNkay5EdXJhdGlvbi5zZWNvbmRzKDUpLFxuICAgICAgICAgICAgaGFuZGxlcjogJ2hhbmRsZXIubWFpbicsXG4gICAgICAgICAgICBjb2RlOiBsYW1iZGEuQ29kZS5mcm9tQXNzZXQocGF0aC5qb2luKF9fZGlybmFtZSwgJy4vJykpLFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBhcGkgPSBuZXcgYXBpZ2F0ZXdheS5SZXN0QXBpKHRoaXMsIFwicHJvZHVjdHMtYXBpXCIsIHtcbiAgICAgICAgICAgIHJlc3RBcGlOYW1lOiBcIlByb2R1Y3RzIEFQSSBHYXRld2F5XCIsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGlzIEFQSSBzZXJ2ZXMgdGhlIExhbWJkYSBmdW5jdGlvbnMuXCJcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgUHJvZHVjdHNMYW1iZGFJbnRlZ3JhdGlvbiA9IG5ldyBhcGlnYXRld2F5LkxhbWJkYUludGVncmF0aW9uKGxhbWJkYUZ1bmN0aW9uLCB7XG4gICAgICAgICAgICBpbnRlZ3JhdGlvblJlc3BvbnNlczogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzQ29kZTogJzIwMCcsXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHByb3h5OiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHByb2R1Y3RzUmVzb3VyY2UgPSBhcGkucm9vdC5hZGRSZXNvdXJjZShcInByb2R1Y3RzXCIpO1xuICAgICAgICBwcm9kdWN0c1Jlc291cmNlLmFkZE1ldGhvZCgnR0VUJywgUHJvZHVjdHNMYW1iZGFJbnRlZ3JhdGlvbiwge1xuICAgICAgICAgICAgbWV0aG9kUmVzcG9uc2VzOiBbIHsgc3RhdHVzQ29kZTogJzIwMCcgfSBdXG4gICAgICAgIH0pO1xuICAgICAgICBwcm9kdWN0c1Jlc291cmNlLmFkZENvcnNQcmVmbGlnaHQoe1xuICAgICAgICAgICAgYWxsb3dPcmlnaW5zOiBbJ2h0dHBzOi8vZDIxNXR4ZTF3bGxydHYuY2xvdWRmcm9udC5uZXQvJ10sXG4gICAgICAgICAgICBhbGxvd01ldGhvZHM6IFsnR0VUJ10sXG4gICAgICAgIH0pO1xuICAgIH1cbn1cblxuIl19