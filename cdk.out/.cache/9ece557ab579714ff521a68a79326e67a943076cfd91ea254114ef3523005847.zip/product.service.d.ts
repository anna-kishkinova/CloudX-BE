export interface Product {
    count: number;
    description: string;
    id: string;
    price: number;
    title: string;
}
export declare function getProducts(): Product[];
export declare function getOneProductById(id: string): Product | undefined;
