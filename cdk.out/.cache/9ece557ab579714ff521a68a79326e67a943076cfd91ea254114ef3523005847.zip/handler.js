"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
exports.getOneProduct = getOneProduct;
const product_service_1 = require("./product.service");
async function main() {
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
            "Access-Control-Allow-Methods": "GET"
        },
        body: JSON.stringify((0, product_service_1.getProducts)()),
    };
}
async function getOneProduct(id) {
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
            "Access-Control-Allow-Methods": "POST"
        },
        body: JSON.stringify((0, product_service_1.getOneProductById)(id)),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFVQztBQUVELHNDQVVDO0FBeEJELHVEQUFtRTtBQUU1RCxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7UUFDZixPQUFPLEVBQUU7WUFDTCw4QkFBOEIsRUFBRyxjQUFjO1lBQy9DLDZCQUE2QixFQUFFLHVDQUF1QztZQUN0RSw4QkFBOEIsRUFBRSxLQUFLO1NBQ3hDO1FBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBQSw2QkFBVyxHQUFFLENBQUM7S0FDdEMsQ0FBQTtBQUNMLENBQUM7QUFFTSxLQUFLLFVBQVUsYUFBYSxDQUFDLEVBQVU7SUFDMUMsT0FBTztRQUNILFVBQVUsRUFBRSxHQUFHO1FBQ2YsT0FBTyxFQUFFO1lBQ0wsOEJBQThCLEVBQUcsY0FBYztZQUMvQyw2QkFBNkIsRUFBRSx1Q0FBdUM7WUFDdEUsOEJBQThCLEVBQUUsTUFBTTtTQUN6QztRQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUEsbUNBQWlCLEVBQUMsRUFBRSxDQUFDLENBQUM7S0FDOUMsQ0FBQTtBQUNMLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRPbmVQcm9kdWN0QnlJZCwgZ2V0UHJvZHVjdHMgfSBmcm9tICcuL3Byb2R1Y3Quc2VydmljZSc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCIgOiBcIkNvbnRlbnQtVHlwZVwiLFxuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCJodHRwczovL2QyMTV0eGUxd2xscnR2LmNsb3VkZnJvbnQubmV0XCIsXG4gICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHNcIjogXCJHRVRcIlxuICAgICAgICB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShnZXRQcm9kdWN0cygpKSxcbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRPbmVQcm9kdWN0KGlkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiIDogXCJDb250ZW50LVR5cGVcIixcbiAgICAgICAgICAgIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luXCI6IFwiaHR0cHM6Ly9kMjE1dHhlMXdsbHJ0di5jbG91ZGZyb250Lm5ldFwiLFxuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzXCI6IFwiUE9TVFwiXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGdldE9uZVByb2R1Y3RCeUlkKGlkKSksXG4gICAgfVxufVxuIl19