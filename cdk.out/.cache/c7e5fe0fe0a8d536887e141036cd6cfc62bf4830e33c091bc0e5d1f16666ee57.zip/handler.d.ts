export declare function main(event: any): Promise<{
    statusCode: number;
    headers: {
        "Access-Control-Allow-Headers": string;
        "Access-Control-Allow-Origin": string;
        "Access-Control-Allow-Methods": string;
    };
    body: string;
}>;
