"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main(event) {
    const productId = event.pathParameters ? event.pathParameters.id : null;
    if (event.httpMethod === 'GET' && productId) {
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
                "Access-Control-Allow-Methods": "GET"
            },
            body: JSON.stringify((0, product_service_1.getOneProductById)(productId)),
        };
    }
    else {
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
                "Access-Control-Allow-Methods": "GET"
            },
            body: JSON.stringify((0, product_service_1.getProducts)()),
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkF3QkM7QUExQkQsdURBQW1FO0FBRTVELEtBQUssVUFBVSxJQUFJLENBQUMsS0FBVTtJQUVqQyxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3hFLElBQUksS0FBSyxDQUFDLFVBQVUsS0FBSyxLQUFLLElBQUksU0FBUyxFQUFFLENBQUM7UUFDMUMsT0FBTztZQUNILFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTyxFQUFFO2dCQUNMLDhCQUE4QixFQUFHLGNBQWM7Z0JBQy9DLDZCQUE2QixFQUFFLHVDQUF1QztnQkFDdEUsOEJBQThCLEVBQUUsS0FBSzthQUN4QztZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUEsbUNBQWlCLEVBQUMsU0FBUyxDQUFDLENBQUM7U0FDckQsQ0FBQTtJQUNMLENBQUM7U0FBTSxDQUFDO1FBQ0osT0FBTztZQUNILFVBQVUsRUFBRSxHQUFHO1lBQ2YsT0FBTyxFQUFFO2dCQUNMLDhCQUE4QixFQUFHLGNBQWM7Z0JBQy9DLDZCQUE2QixFQUFFLHVDQUF1QztnQkFDdEUsOEJBQThCLEVBQUUsS0FBSzthQUN4QztZQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUEsNkJBQVcsR0FBRSxDQUFDO1NBQ3RDLENBQUE7SUFDTCxDQUFDO0FBQ0wsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldE9uZVByb2R1Y3RCeUlkLCBnZXRQcm9kdWN0cyB9IGZyb20gJy4vcHJvZHVjdC5zZXJ2aWNlJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oZXZlbnQ6IGFueSkge1xuXG4gICAgY29uc3QgcHJvZHVjdElkID0gZXZlbnQucGF0aFBhcmFtZXRlcnMgPyBldmVudC5wYXRoUGFyYW1ldGVycy5pZCA6IG51bGw7XG4gICAgaWYgKGV2ZW50Lmh0dHBNZXRob2QgPT09ICdHRVQnICYmIHByb2R1Y3RJZCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVyc1wiIDogXCJDb250ZW50LVR5cGVcIixcbiAgICAgICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcImh0dHBzOi8vZDIxNXR4ZTF3bGxydHYuY2xvdWRmcm9udC5uZXRcIixcbiAgICAgICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHNcIjogXCJHRVRcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGdldE9uZVByb2R1Y3RCeUlkKHByb2R1Y3RJZCkpLFxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIiA6IFwiQ29udGVudC1UeXBlXCIsXG4gICAgICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCJodHRwczovL2QyMTV0eGUxd2xscnR2LmNsb3VkZnJvbnQubmV0XCIsXG4gICAgICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzXCI6IFwiR0VUXCJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShnZXRQcm9kdWN0cygpKSxcbiAgICAgICAgfVxuICAgIH1cbn1cbiJdfQ==