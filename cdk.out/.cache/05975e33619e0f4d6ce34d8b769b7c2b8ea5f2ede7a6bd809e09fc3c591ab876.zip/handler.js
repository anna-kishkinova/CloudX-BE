"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main() {
    return {
        statusCode: 200,
        // You have to handle CORS headers on your own
        headers: {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
            "Access-Control-Allow-Methods": "GET"
        },
        body: JSON.stringify((0, product_service_1.getProducts)()),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFXQztBQWJELHVEQUFnRDtBQUV6QyxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7UUFDZiw4Q0FBOEM7UUFDOUMsT0FBTyxFQUFFO1lBQ0wsOEJBQThCLEVBQUcsY0FBYztZQUMvQyw2QkFBNkIsRUFBRSx1Q0FBdUM7WUFDdEUsOEJBQThCLEVBQUUsS0FBSztTQUN4QztRQUNELElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUEsNkJBQVcsR0FBRSxDQUFDO0tBQ3RDLENBQUE7QUFDTCxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0UHJvZHVjdHMgfSBmcm9tICcuL3Byb2R1Y3Quc2VydmljZSc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYWluKCkge1xuICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgLy8gWW91IGhhdmUgdG8gaGFuZGxlIENPUlMgaGVhZGVycyBvbiB5b3VyIG93blxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIiA6IFwiQ29udGVudC1UeXBlXCIsXG4gICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcImh0dHBzOi8vZDIxNXR4ZTF3bGxydHYuY2xvdWRmcm9udC5uZXRcIixcbiAgICAgICAgICAgIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kc1wiOiBcIkdFVFwiXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGdldFByb2R1Y3RzKCkpLFxuICAgIH1cbn1cbiJdfQ==