"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main() {
    return {
        body: JSON.stringify((0, product_service_1.getProducts)()),
        statusCode: 200,
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFLQztBQVBELHVEQUFnRDtBQUV6QyxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPO1FBQ0gsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBQSw2QkFBVyxHQUFFLENBQUM7UUFDbkMsVUFBVSxFQUFFLEdBQUc7S0FDbEIsQ0FBQztBQUNOLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRQcm9kdWN0cyB9IGZyb20gJy4vcHJvZHVjdC5zZXJ2aWNlJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZ2V0UHJvZHVjdHMoKSksXG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICB9O1xufVxuIl19