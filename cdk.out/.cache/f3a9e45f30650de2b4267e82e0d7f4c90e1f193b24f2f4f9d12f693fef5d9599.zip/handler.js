"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main() {
    return {
        statusCode: 200,
        headers: {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "https://d215txe1wllrtv.cloudfront.net",
            "Access-Control-Allow-Methods": "GET"
        },
        body: JSON.stringify((0, product_service_1.getProducts)()),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFVQztBQVpELHVEQUFnRDtBQUV6QyxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7UUFDZixPQUFPLEVBQUU7WUFDTCw4QkFBOEIsRUFBRyxjQUFjO1lBQy9DLDZCQUE2QixFQUFFLHVDQUF1QztZQUN0RSw4QkFBOEIsRUFBRSxLQUFLO1NBQ3hDO1FBQ0QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBQSw2QkFBVyxHQUFFLENBQUM7S0FDdEMsQ0FBQTtBQUNMLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRQcm9kdWN0cyB9IGZyb20gJy4vcHJvZHVjdC5zZXJ2aWNlJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnNcIiA6IFwiQ29udGVudC1UeXBlXCIsXG4gICAgICAgICAgICBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcImh0dHBzOi8vZDIxNXR4ZTF3bGxydHYuY2xvdWRmcm9udC5uZXRcIixcbiAgICAgICAgICAgIFwiQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kc1wiOiBcIkdFVFwiXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGdldFByb2R1Y3RzKCkpLFxuICAgIH1cbn1cbiJdfQ==