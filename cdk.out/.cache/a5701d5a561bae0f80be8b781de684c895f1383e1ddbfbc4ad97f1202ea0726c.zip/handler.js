"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main() {
    return {
        statusCode: 200,
        // You have to handle CORS headers on your own
        headers: {
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Origin": "YOUR_URL",
            "Access-Control-Allow-Methods": "GET"
        },
        body: JSON.stringify((0, product_service_1.getProducts)()),
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFXQztBQWJELHVEQUFnRDtBQUV6QyxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPO1FBQ0gsVUFBVSxFQUFFLEdBQUc7UUFDZiw4Q0FBOEM7UUFDOUMsT0FBTyxFQUFFO1lBQ0wsOEJBQThCLEVBQUcsY0FBYztZQUMvQyw2QkFBNkIsRUFBRSxVQUFVO1lBQ3pDLDhCQUE4QixFQUFFLEtBQUs7U0FDeEM7UUFDRCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFBLDZCQUFXLEdBQUUsQ0FBQztLQUN0QyxDQUFBO0FBQ0wsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdldFByb2R1Y3RzIH0gZnJvbSAnLi9wcm9kdWN0LnNlcnZpY2UnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFpbigpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgIC8vIFlvdSBoYXZlIHRvIGhhbmRsZSBDT1JTIGhlYWRlcnMgb24geW91ciBvd25cbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzXCIgOiBcIkNvbnRlbnQtVHlwZVwiLFxuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW5cIjogXCJZT1VSX1VSTFwiLFxuICAgICAgICAgICAgXCJBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzXCI6IFwiR0VUXCJcbiAgICAgICAgfSxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZ2V0UHJvZHVjdHMoKSksXG4gICAgfVxufVxuIl19