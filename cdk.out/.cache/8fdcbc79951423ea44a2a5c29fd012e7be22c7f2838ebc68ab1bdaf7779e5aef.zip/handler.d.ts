export declare function main(): Promise<import("./product.service").Product[]>;
