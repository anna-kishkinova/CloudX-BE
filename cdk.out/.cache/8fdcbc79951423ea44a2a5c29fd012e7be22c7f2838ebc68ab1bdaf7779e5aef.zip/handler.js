"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
const product_service_1 = require("./product.service");
async function main() {
    return (0, product_service_1.getProducts)();
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxvQkFFQztBQUpELHVEQUFnRDtBQUV6QyxLQUFLLFVBQVUsSUFBSTtJQUN0QixPQUFPLElBQUEsNkJBQVcsR0FBRSxDQUFDO0FBQ3pCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRQcm9kdWN0cyB9IGZyb20gJy4vcHJvZHVjdC5zZXJ2aWNlJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgcmV0dXJuIGdldFByb2R1Y3RzKCk7XG59XG4iXX0=