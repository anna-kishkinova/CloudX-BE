import { getProducts } from './product.service';

export async function main() {
    return getProducts();
}
