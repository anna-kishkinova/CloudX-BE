"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.main = main;
async function main() {
    return {
        body: JSON.stringify({ message: 'Hello from Lambda 🎉' }),
        statusCode: 200,
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaGFuZGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxvQkFLQztBQUxNLEtBQUssVUFBVSxJQUFJO0lBQ3RCLE9BQU87UUFDSCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFDLE9BQU8sRUFBRSxzQkFBc0IsRUFBQyxDQUFDO1FBQ3ZELFVBQVUsRUFBRSxHQUFHO0tBQ2xCLENBQUM7QUFDTixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe21lc3NhZ2U6ICdIZWxsbyBmcm9tIExhbWJkYSDwn46JJ30pLFxuICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgfTtcbn1cbiJdfQ==