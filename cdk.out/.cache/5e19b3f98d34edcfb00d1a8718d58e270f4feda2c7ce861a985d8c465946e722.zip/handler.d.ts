export declare function main(): Promise<{
    body: string;
    statusCode: number;
}>;
