"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsLambdaStack = void 0;
const lambda = require("aws-cdk-lib/aws-lambda");
const cdk = require("aws-cdk-lib");
const path = require("path");
const apigateway = require("aws-cdk-lib/aws-apigateway");
class ProductsLambdaStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const lambdaFunction = new lambda.Function(this, 'getProductsList', {
            runtime: lambda.Runtime.NODEJS_20_X,
            memorySize: 1024,
            timeout: cdk.Duration.seconds(5),
            handler: 'handler.main',
            code: lambda.Code.fromAsset(path.join(__dirname, './')),
        });
        const api = new apigateway.RestApi(this, "products-api", {
            restApiName: "Products API Gateway",
            description: "This API serves the Lambda functions."
        });
        //
        // const ProductsLambdaIntegration = new apigateway.LambdaIntegration(lambdaFunction, {
        //     integrationResponses: [
        //         {
        //             statusCode: '200',
        //         }
        //
        //     ],
        //     // proxy: false,
        // });
        const ProductsLambdaIntegration = new apigateway.LambdaIntegration(lambdaFunction);
        const productsResource = api.root.addResource("products");
        productsResource.addMethod('GET', ProductsLambdaIntegration);
        // productsResource.addMethod('GET', ProductsLambdaIntegration, {
        //     methodResponses: [ { statusCode: '200' } ]
        // });
        // productsResource.addCorsPreflight({
        //     allowOrigins: ['https://d215txe1wllrtv.cloudfront.net'],
        //     allowMethods: ['GET'],
        // });
    }
}
exports.ProductsLambdaStack = ProductsLambdaStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdHMtbGFtYmRhLXN0YWNrLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicHJvZHVjdHMtbGFtYmRhLXN0YWNrLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGlEQUFpRDtBQUNqRCxtQ0FBbUM7QUFDbkMsNkJBQTZCO0FBRTdCLHlEQUF5RDtBQUV6RCxNQUFhLG1CQUFvQixTQUFRLEdBQUcsQ0FBQyxLQUFLO0lBQzlDLFlBQVksS0FBZ0IsRUFBRSxFQUFVLEVBQUUsS0FBc0I7UUFDNUQsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFFeEIsTUFBTSxjQUFjLEdBQUcsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxpQkFBaUIsRUFBRTtZQUNoRSxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ25DLFVBQVUsRUFBRSxJQUFJO1lBQ2hCLE9BQU8sRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDaEMsT0FBTyxFQUFFLGNBQWM7WUFDdkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1NBQzFELENBQUMsQ0FBQztRQUVILE1BQU0sR0FBRyxHQUFHLElBQUksVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsY0FBYyxFQUFFO1lBQ3JELFdBQVcsRUFBRSxzQkFBc0I7WUFDbkMsV0FBVyxFQUFFLHVDQUF1QztTQUN2RCxDQUFDLENBQUM7UUFDSCxFQUFFO1FBQ0YsdUZBQXVGO1FBQ3ZGLDhCQUE4QjtRQUM5QixZQUFZO1FBQ1osaUNBQWlDO1FBQ2pDLFlBQVk7UUFDWixFQUFFO1FBQ0YsU0FBUztRQUNULHVCQUF1QjtRQUN2QixNQUFNO1FBRU4sTUFBTSx5QkFBeUIsR0FBRyxJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUVuRixNQUFNLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRTFELGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUseUJBQXlCLENBQUMsQ0FBQztRQUU3RCxpRUFBaUU7UUFDakUsaURBQWlEO1FBQ2pELE1BQU07UUFDTixzQ0FBc0M7UUFDdEMsK0RBQStEO1FBQy9ELDZCQUE2QjtRQUM3QixNQUFNO0lBQ1YsQ0FBQztDQUNKO0FBekNELGtEQXlDQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5pbXBvcnQgKiBhcyBhcGlnYXRld2F5IGZyb20gXCJhd3MtY2RrLWxpYi9hd3MtYXBpZ2F0ZXdheVwiO1xuXG5leHBvcnQgY2xhc3MgUHJvZHVjdHNMYW1iZGFTdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG4gICAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM/OiBjZGsuU3RhY2tQcm9wcykge1xuICAgICAgICBzdXBlcihzY29wZSwgaWQsIHByb3BzKTtcblxuICAgICAgICBjb25zdCBsYW1iZGFGdW5jdGlvbiA9IG5ldyBsYW1iZGEuRnVuY3Rpb24odGhpcywgJ2dldFByb2R1Y3RzTGlzdCcsIHtcbiAgICAgICAgICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLk5PREVKU18yMF9YLFxuICAgICAgICAgICAgbWVtb3J5U2l6ZTogMTAyNCxcbiAgICAgICAgICAgIHRpbWVvdXQ6IGNkay5EdXJhdGlvbi5zZWNvbmRzKDUpLFxuICAgICAgICAgICAgaGFuZGxlcjogJ2hhbmRsZXIubWFpbicsXG4gICAgICAgICAgICBjb2RlOiBsYW1iZGEuQ29kZS5mcm9tQXNzZXQocGF0aC5qb2luKF9fZGlybmFtZSwgJy4vJykpLFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBhcGkgPSBuZXcgYXBpZ2F0ZXdheS5SZXN0QXBpKHRoaXMsIFwicHJvZHVjdHMtYXBpXCIsIHtcbiAgICAgICAgICAgIHJlc3RBcGlOYW1lOiBcIlByb2R1Y3RzIEFQSSBHYXRld2F5XCIsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogXCJUaGlzIEFQSSBzZXJ2ZXMgdGhlIExhbWJkYSBmdW5jdGlvbnMuXCJcbiAgICAgICAgfSk7XG4gICAgICAgIC8vXG4gICAgICAgIC8vIGNvbnN0IFByb2R1Y3RzTGFtYmRhSW50ZWdyYXRpb24gPSBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbihsYW1iZGFGdW5jdGlvbiwge1xuICAgICAgICAvLyAgICAgaW50ZWdyYXRpb25SZXNwb25zZXM6IFtcbiAgICAgICAgLy8gICAgICAgICB7XG4gICAgICAgIC8vICAgICAgICAgICAgIHN0YXR1c0NvZGU6ICcyMDAnLFxuICAgICAgICAvLyAgICAgICAgIH1cbiAgICAgICAgLy9cbiAgICAgICAgLy8gICAgIF0sXG4gICAgICAgIC8vICAgICAvLyBwcm94eTogZmFsc2UsXG4gICAgICAgIC8vIH0pO1xuXG4gICAgICAgIGNvbnN0IFByb2R1Y3RzTGFtYmRhSW50ZWdyYXRpb24gPSBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbihsYW1iZGFGdW5jdGlvbik7XG5cbiAgICAgICAgY29uc3QgcHJvZHVjdHNSZXNvdXJjZSA9IGFwaS5yb290LmFkZFJlc291cmNlKFwicHJvZHVjdHNcIik7XG5cbiAgICAgICAgcHJvZHVjdHNSZXNvdXJjZS5hZGRNZXRob2QoJ0dFVCcsIFByb2R1Y3RzTGFtYmRhSW50ZWdyYXRpb24pO1xuXG4gICAgICAgIC8vIHByb2R1Y3RzUmVzb3VyY2UuYWRkTWV0aG9kKCdHRVQnLCBQcm9kdWN0c0xhbWJkYUludGVncmF0aW9uLCB7XG4gICAgICAgIC8vICAgICBtZXRob2RSZXNwb25zZXM6IFsgeyBzdGF0dXNDb2RlOiAnMjAwJyB9IF1cbiAgICAgICAgLy8gfSk7XG4gICAgICAgIC8vIHByb2R1Y3RzUmVzb3VyY2UuYWRkQ29yc1ByZWZsaWdodCh7XG4gICAgICAgIC8vICAgICBhbGxvd09yaWdpbnM6IFsnaHR0cHM6Ly9kMjE1dHhlMXdsbHJ0di5jbG91ZGZyb250Lm5ldCddLFxuICAgICAgICAvLyAgICAgYWxsb3dNZXRob2RzOiBbJ0dFVCddLFxuICAgICAgICAvLyB9KTtcbiAgICB9XG59XG5cbiJdfQ==